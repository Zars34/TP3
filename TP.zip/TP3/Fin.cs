﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    internal class Fin
    {
        public double RND;
        public double tiempo;
        public double ACTiempoAtencion;
        //Porcentaje
        public double PRCOcupacion;
        //Contiene las horas del fin de atencion de cada cola
        public List<double> finAtencion;

        public int media;
        public ClienteTemporal clienteTemporal;
    }
}
