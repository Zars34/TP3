namespace TP3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            GestorFilas gestor;
            gestor.Inicio();
        }
    }
}
