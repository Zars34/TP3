﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    internal class Llegada
    {
        public double RND;
        public double tiempo;
        public double proxLlegada;

        public int media;

        public ClienteTemporal clienteTemporal;
    }
}
