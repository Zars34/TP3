﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    internal class Cola
    {
        public List<ClienteTemporal> cantidad;
        public double tiempoEspera = 0;
        //Porcentaje Tiempo Fuera
        public double PRCtiempoFuera;
    }
}
