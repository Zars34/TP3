﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    internal class ServicioAdicional
    {
        public double RND;
        //Revisa si toma el cliente toma o no el servicio
        public bool tomaServicio;

    }
}
